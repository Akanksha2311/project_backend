const db = require('../util/database');

const getContact  = (req, res, next) => {
    const query=`SELECT * FROM contact `;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            contact: dbRes.rows
                });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const addContact = (req, res, next) => {
    const query = `
        INSERT INTO  contact
        VALUES (
            '${req.body.name}',
            '${req.body.email}',
            '${req.body.message}'
            )`;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            message:"Contact added Successfully.",
            data: dbRes.rows
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}


const deleteContact = (req, res, next) => {
    const query = `
        DELETE FROM contact
        WHERE email='${req.params.email}'
    `;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            message: 'Contact Deleted Successfully'
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

module.exports = {
    getContact ,
    addContact ,
    deleteContact
};