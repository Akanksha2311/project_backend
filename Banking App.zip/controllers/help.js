const db = require('../util/database');

const getContact  = (req, res, next) => {
    const query=`SELECT * FROM online_help `;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            help: dbRes.rows
                });
    }).catch(dbErr => {
        next(dbErr);
    });
}

//online_help name, email, acount_number, phone_number, details, branch_name, branch_city, address)

const addForm = (req, res, next) => {
    const query = `
        INSERT INTO  online_help 
        VALUES (
            '${req.body.name}',
            '${req.body.email}',
            ${req.body.acount_number},
            ${req.body.phone_number},
            '${req.body.details}',
            '${req.body.branch_name}',
            '${req.body.branch_city}',
            '${req.body.address}'
            )`;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            message:"Form Submitted Successfully .",
            data: dbRes.rows
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}


const deleteForm = (req, res, next) => {
    const query = `
        DELETE FROM online_help
        WHERE email='${req.params.email}'
    `;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            message: ' Deleted Successfully'
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

module.exports = {
    getContact ,
    addForm ,
    deleteForm
};