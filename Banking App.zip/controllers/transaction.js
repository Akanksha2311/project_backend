const db = require('../util/database');
const { v4: uuidv4 } = require('uuid');

const getAllTranscation = (req, res, next) => {
    const query=`SELECT * FROM  transcation`;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            transcation: dbRes.rows
                });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const sendMoney = (req, res, next) => {
    const query = `
        INSERT INTO transcation
        VALUES (
            '${uuidv4()}', 
            0 ,
            ${req.body.debit_amount},
            '${req.body.remark}'
            )`;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            transcation: dbRes.rows
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const receiveMoney = (req, res, next) => {
    const query = `
        INSERT INTO transcation
        VALUES (
            '${uuidv4()}', 
            ${req.body.credit_amount},
            0 ,
            '${req.body.remark}'
            )`;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            transcation: dbRes.rows
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const deleteHistory = (req, res, next) => {
    const query = `
        DELETE FROM transcation
        WHERE id='${req.params.id}'
    `;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            message: ' Deleted Successfully'
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}


module.exports = {  getAllTranscation , sendMoney , deleteHistory , receiveMoney };