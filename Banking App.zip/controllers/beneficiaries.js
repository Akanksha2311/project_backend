const db = require('../util/database');

// middleware to check email availability
const checkEmailAvailability = (req, res, next) => {
    const query = `
        SELECT * FROM beneficiaries
        WHERE email='${req.body.email}'
    `;
    db.query(query).then(dbRes => {
        if (dbRes.rows.length > 0) {
            res.json({
                error: true,
                message: 'Email already exists'
            });
           
        } else {
            next();

        }
    }).catch(dbErr => {
        next(dbErr);
    });
}

const getAllBeneficiaries = (req, res, next) => {
    const query=`SELECT * FROM beneficiaries`;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            Beneficiaries: dbRes.rows
                });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const getBeneficiaries = (req,res,next) => {
    const query = `SELECT COUNT(*) FROM beneficiaries `;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            Beneficiaries: dbRes.rows
        });
    }).catch(dbErr => {
        next(dbErr);
    })
}

const getSingleBeneficiaries = (req, res, next) => {
    const query=`SELECT * FROM beneficiaries WHERE email='${req.params.email}' `;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            Beneficiaries: dbRes.rows
                });
    }).catch(dbErr => {
        next(dbErr);
    });
}

// INSERT INTO public.beneficiaries(
// 	first_name, last_name, acount_number, email, phone_number)


const addBeneficiaries = (req, res, next) => {
    const query = `
        INSERT INTO  beneficiaries
        VALUES (
            '${req.body.first_name}',
            '${req.body.last_name}',
            ${req.body.acount_number},
            '${req.body.email}',
            ${req.body.phone_number}
            )`;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            message:"Benificiaries added Successfully.",
            data: dbRes.rows
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

// INSERT INTO public.beneficiaries(
// 	first_name, last_name, acount_number, email, phone_number)
const updateBeneficiaries = (req, res, next) => {
    console.log(req.params.email);
    // console.log(req.body.firstName)
    const updateQuery = `
        UPDATE  beneficiaries
          SET 
          first_name='${req.body.first_name}',
            last_name='${req.body.last_name}',
            acount_number=${req.body.acount_number},
            phone_number=${req.body.phone_number}
        WHERE email='${req.params.email}'
    `;
    db.query(updateQuery).then(dbRes => {
        res.json({
            error: false,
            message: 'Beneficiaries details updated successfully'
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const deleteBeneficiaries = (req, res, next) => {
    const query = `
        DELETE FROM beneficiaries
        WHERE email='${req.params.email}'
    `;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            message: 'Beneficiaries Deleted Successfully'
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

module.exports = {
    getAllBeneficiaries ,
    addBeneficiaries ,
    updateBeneficiaries,
    checkEmailAvailability,
    deleteBeneficiaries,
    getSingleBeneficiaries,
    getBeneficiaries
};