const db = require('../util/database');
const { v4: uuidv4 } = require('uuid');

// middleware to check email availability
const checkEmailAvailability = (req, res, next) => {
    const query = `
        SELECT * FROM mycustomer
        WHERE email='${req.body.email}'
    `;
    db.query(query).then(dbRes => {
        if (dbRes.rows.length > 0) {
            res.json({
                error: true,
                message: 'Email already exists'
            });
        } else {
            next();
        }
    }).catch(dbErr => {
        next(dbErr);
    });
}

const getAllCustomers = (req, res, next) => {
    const query=`SELECT * FROM mycustomer`;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            myCustomer: dbRes.rows
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const getSingleCustomer = (req, res, next) => {
    const query=`SELECT * FROM mycustomer WHERE email='${req.params.email}' `;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            myCustomer: dbRes.rows
                });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const addCustomer = (req, res, next) => {
    const query = `
        INSERT INTO mycustomer
        VALUES (
            '${req.body.first_name}',
            '${req.body.last_name}',
            '${req.body.gender}',
            '${req.body.email}',
            ${req.body.aadhar_no},
            ${req.body.phone_no},
            '${req.body.address}',
            ${req.body.acount_no},
            ${req.body.pin},
            ${req.body.opening_balnce}
            )`;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            data: dbRes.rows,
            message: 'Customer added successfully'
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}
// first_name, last_name, gender, email, aadhar_no, phone_no, address, acount_no, pin, opening_balnce)
const updateCustomer = (req, res, next) => {
    console.log(req.params.email);
    const updateQuery = `
        UPDATE mycustomer
        SET 
        first_name='${req.body.first_name}',
        last_name='${req.body.last_name}',
        phone_no=${req.body.phone_no},
        address='${req.body.address}',
        pin=${req.body.pin}
     WHERE email='${req.params.email}'
    `;
    db.query(updateQuery).then(dbRes => {
        res.json({
            error: false,
            message: 'Customer details updated successfully'
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const deleteCustomer = (req, res, next) => {
    const query = `
        DELETE FROM mycustomer
        WHERE email='${req.params.email}'
    `;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            message: 'Customer Deleted Successfully'
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

module.exports = {
    getAllCustomers ,
    addCustomer ,
    updateCustomer,
    checkEmailAvailability,
    deleteCustomer,
    getSingleCustomer
};