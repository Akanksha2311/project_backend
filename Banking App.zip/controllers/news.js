const db = require('../util/database');
const { v4: uuidv4 } = require('uuid');

const checkNewsId = (req, res, next) => {
    const checkAvailability = `
        SELECT * FROM news
        WHERE id='${req.params.id}'
    `;
    db.query(checkAvailability).then(dbRes => {
        if (dbRes.rows.length > 0) {
            next();
        } else {
            res.json({
                error: true,
                message: 'No news found with the ID'
            });
        }
    });
}

const getAllNews = (req, res, next) => {
    const query = 'SELECT * FROM news';
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            news: dbRes.rows
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const addNews = (req, res, next) => {
    const query = `
        INSERT INTO news
        VALUES (
            '${uuidv4()}', 
            '${req.body.headline}',
            '${req.body.details}'
            )`;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            data: dbRes.rows
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}


const deleteNews = (req, res, next) => {
    const query = `
        DELETE FROM news
        WHERE id='${req.params.id}'
    `;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            message: 'News Deleted Successfully'
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

module.exports = {
    checkNewsId,
    getAllNews,
    addNews,
    deleteNews
};