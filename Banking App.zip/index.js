const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');
const port = 8000;

// const db = require('./util/database');

//routes
const myCustomerRoutes = require('./routes/myCustomer');
const beneficiariesRoutes = require('./routes/beneficiaries');
const transcationRoutes = require('./routes/transaction');
const newsRoutes = require('./routes/news');
const userRoutes = require('./routes/users');
const contactRoutes =require('./routes/contact');
const helpRoutes = require('./routes/help');

// cors middleware
app.use(cors());

// body parser middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use('/myCustomer',myCustomerRoutes);
app.use('/beneficiaries',beneficiariesRoutes);
app.use('/transcation',transcationRoutes);
app.use('/news',newsRoutes);
app.use('/user',userRoutes);
app.use('/contact',contactRoutes);
app.use('/help',helpRoutes);

// error handling middleware
// app.use((err, req, res, next) => {
//     res.send({
//         error: true,
//         message: 'Server Error',
//         err: err
//     });
// });

app.listen(port , ()=>{
    console.log(`App is listening to port ${port}`);
});