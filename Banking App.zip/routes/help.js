const express = require('express');
const router = express.Router();

const helpController = require('../controllers/help');


router.get('/',helpController.getContact);
router.post('/',helpController.addForm);
router.delete('/:email',  helpController.deleteForm);

module.exports = router;