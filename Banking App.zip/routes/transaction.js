const express = require('express');
const router = express.Router();

const transcationController = require('../controllers/transaction');

router.get('/',transcationController.getAllTranscation  );
router.post('/send',transcationController.sendMoney);
router.post('/receive',transcationController.receiveMoney);
router.delete('/:id',transcationController.deleteHistory);

module.exports = router;