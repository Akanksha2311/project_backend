const express = require('express');
const router = express.Router();

const auth = require('../middlewares/auth')
const myCustomerController = require('../controllers/myCustomer');

router.get('/',myCustomerController.getAllCustomers);
router.get('/:email',myCustomerController.getSingleCustomer)
router.post('/',auth.checkAdmin, myCustomerController.checkEmailAvailability, myCustomerController.addCustomer);
router.put('/:email', myCustomerController.updateCustomer);
router.delete('/:email',  myCustomerController.checkEmailAvailability, myCustomerController.deleteCustomer);

module.exports = router;