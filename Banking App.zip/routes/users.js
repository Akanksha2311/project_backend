const express = require('express');
const router = express.Router();

const auth = require('../middlewares/auth');
const userController = require('../controllers/users');

router.get('/', userController.getAllUsers);

router.post('/register' ,userController.checkEmailAvailability, userController.addUser);
router.post('/login', userController.checkUserLogin);

router.put('/:email', auth.checkCustomer,  userController.updateUser);

router.delete('/:email', auth.checkCustomer, userController.deleteUser);

module.exports = router;