const express = require('express');
const router = express.Router();

const contactController = require('../controllers/contact');


router.get('/',contactController.getContact);
router.post('/',contactController.addContact);
router.delete('/:email',  contactController.deleteContact);

module.exports = router;