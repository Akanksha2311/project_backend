const express = require('express');
const router = express.Router();

const beneficiariesController = require('../controllers/beneficiaries');


router.get('/',beneficiariesController.getAllBeneficiaries);
router.get('/count',beneficiariesController.getBeneficiaries)
router.get('/edit/:email',beneficiariesController.getSingleBeneficiaries);
router.post('/',beneficiariesController.checkEmailAvailability, beneficiariesController.addBeneficiaries);
router.put('/:email',beneficiariesController.checkEmailAvailability , beneficiariesController.updateBeneficiaries);
router.delete('/:email',  beneficiariesController.checkEmailAvailability, beneficiariesController.deleteBeneficiaries);

module.exports = router;